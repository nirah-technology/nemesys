"""Bag object"""
from .bag import Bag