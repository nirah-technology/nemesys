class Color:
    def __init__(self, red: int, green: int, blue: int, alpha: float=1) -> None:
        self.red: int = red
        self.green: int = green
        self.blue: int = blue
        self.alpha: float = alpha
    
    
